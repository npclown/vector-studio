# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: p1-primitives.spec.ts >> P1 latest-scene recovery samples1
- Location: tests\gpu\p1-primitives.spec.ts:136:3

# Error details

```
Error: page.evaluate: Error: {"code":"device-loss.detected","message":"The active WebGPU device was lost.","severity":"error","generation":1,"context":{"reason":"destroyed","message":"Device was destroyed."},"sequence":1,"timestampMs":1789199444599}
    at http://127.0.0.1:4175/src/p1-fixture.ts:149:18
    at DiagnosticChannel.emit (http://127.0.0.1:4175/@fs/D:/GIT/vector-studio/packages/renderer-core/dist/diagnostic-channel.js:41:17)
    at #emit (http://127.0.0.1:4175/@fs/D:/GIT/vector-studio/packages/renderer-webgpu/dist/webgpu-backend.js:866:34)
    at #handleDeviceLoss (http://127.0.0.1:4175/@fs/D:/GIT/vector-studio/packages/renderer-webgpu/dist/webgpu-backend.js:531:19)
    at http://127.0.0.1:4175/@fs/D:/GIT/vector-studio/packages/renderer-webgpu/dist/webgpu-backend.js:501:63
```